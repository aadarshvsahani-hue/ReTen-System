from flask import Flask, request, jsonify
import numpy as np
import pandas as pd
import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBClassifier

app = Flask(__name__)

# Load the scaler
scaler_filename = 'scaler.joblib'
loaded_scaler = joblib.load(scaler_filename)

# Load the trained models
model_rf_reg = joblib.load('model_rf_reg.joblib')
model_xgb_clf = joblib.load('model_xgb_clf.joblib')
model_clf = joblib.load('model_clf.joblib')

# Define the preprocessing function (must match the one used during training)
def preprocess_input_data(data, scaler, X_columns, categorical_cols, numerical_cols):
    # Convert input JSON data to a pandas DataFrame
    input_df = pd.DataFrame([data])

    # Convert 'user_id' to string if it exists in input_df, just in case
    if 'user_id' in input_df.columns:
        input_df['user_id'] = input_df['user_id'].astype(str)

    # One-hot encode categorical features
    input_df_encoded = pd.get_dummies(input_df, columns=categorical_cols, drop_first=True, dtype=int)

    # Align columns with the training data (X_reg or X_clf) to handle missing or extra columns
    processed_input = pd.DataFrame(0, index=input_df_encoded.index, columns=X_columns)
    for col in input_df_encoded.columns:
        if col in processed_input.columns:
            processed_input[col] = input_df_encoded[col]

    # Drop 'user_id_numeric' if it was part of the original X_columns but not intended for prediction
    if 'user_id_numeric' in processed_input.columns:
        processed_input = processed_input.drop(columns=['user_id_numeric'])

    # Apply scaling to numerical features
    processed_input[numerical_cols] = scaler.transform(processed_input[numerical_cols])

    return processed_input

# --- Regression Scenario (Predicting performance_score) ---
file_path_preprocessed = 'ReTen_Final_Organized_Dataset.xlsx'
df_preprocessed = pd.read_excel(file_path_preprocessed)

df_preprocessed['Daily_Calorie_intake'] = df_preprocessed['Daily_Calorie_intake'].fillna(df_preprocessed['Daily_Calorie_intake'].median())
df_preprocessed['Supplements_Taken'] = df_preprocessed['Supplements_Taken'].fillna(df_preprocessed['Supplements_Taken'].mode()[0])
df_preprocessed['performance_score'] = df_preprocessed['performance_score'].fillna(df_preprocessed['performance_score'].median())

categorical_cols_to_encode = [col for col in df_preprocessed.select_dtypes(include='object').columns.tolist() if col != 'user_id']
df_encoded_temp = pd.get_dummies(df_preprocessed, columns=categorical_cols_to_encode, drop_first=True, dtype=int)

numerical_columns = df_encoded_temp.select_dtypes(include=np.number).columns.tolist()
binary_columns = []
for col in numerical_columns:
    unique_values = df_encoded_temp[col].unique()
    if len(unique_values) <= 2 and all(val in [0, 1] for val in unique_values):
        binary_columns.append(col)
numerical_cols_to_scale = [col for col in numerical_columns if col not in binary_columns]

y_reg_dummy = df_encoded_temp['performance_score']
X_reg_dummy = df_encoded_temp.drop(columns=['user_id', 'performance_score'])
X_columns_reg = X_reg_dummy.columns.tolist()

X_columns_clf = X_reg_dummy.columns.tolist()

@app.route('/predict_performance', methods=['POST'])
def predict_performance():
    try:
        data = request.get_json(force=True)

        categorical_cols = [col for col in df_preprocessed.select_dtypes(include='object').columns.tolist() if col != 'user_id']

        processed_input = preprocess_input_data(data, loaded_scaler, X_columns_reg, categorical_cols, numerical_cols_to_scale)

        prediction = model_rf_reg.predict(processed_input)[0]

        return jsonify({'performance_score': prediction.tolist()})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/classify_user', methods=['POST'])
def classify_user():
    try:
        data = request.get_json(force=True)

        categorical_cols = [col for col in df_preprocessed.select_dtypes(include='object').columns.tolist() if col != 'user_id']

        processed_input = preprocess_input_data(data, loaded_scaler, X_columns_clf, categorical_cols, numerical_cols_to_scale)

        primary_prediction = model_xgb_clf.predict(processed_input)[0]

        secondary_probabilities = model_clf.predict_proba(processed_input)[0]

        return jsonify({
            'user_type_prediction': int(primary_prediction),
            'is_regular_user_proba': secondary_probabilities[1].tolist(),
            'is_irregular_user_proba': secondary_probabilities[0].tolist()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)